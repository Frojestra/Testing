<?php
//check the file
//open txt file
function parsefile($filename){

	$calllog = fopen($filename,"r") or die("Unable to open file");
	//read file line by line and parse the log into required format
	$logarray = array("Date,Time,Duration,Source,Direction,Distination,Staff,Local");
	$time = 0;
	while(!feof($calllog))
	{
		$time++;
		$line = fgets($calllog);
		//if it is not empty line or did not start with * nor the first three lines
		if(!strpos($line,"***")&& strlen($line)>0 && $time>2)
		{
			$linearray = explode(":",$line);
			$newline = substr_replace($linearray[2],',',10,0);

			for ($i=3;$i < count($linearray); $i++)
			{
				$newline = $newline.":".$linearray[$i];
			}
			$newarray = explode(",",$newline);
			$lineinfo = $newarray[0];
			for($i=1;$i<count($newarray);$i++)
			{
				switch ($i) {
					case '3':
						break;
					case '7':
						break;
					case '9':
						break;
					case '10':
						break;
					case '12':
						break;
					case '13':
						break;
					case '14':
						break;
					default:
						$lineinfo = $lineinfo.",".$newarray[i];
						break;
				}//switch end
			}//for end
			array_push($logarray,$lineinfo);
		}//if end

	}//while end
	fclose($filename);
	//save to csv
	if(strlen($logarray)>0)
	{
		outputcsv($logarray,explode(".",$filename)[0]);
	}
}//function end


function outputcsv($array,$filename)
{
	$file = fopen($filename+".csv","w") or die("Unable to open file");

	foreach ($array as $line)
	{
		fputcsv($file,explode(',',$line));
	}

	fclose($file);
}

function execute()
{
	$address = "D:\\Prestige Real Estate\Parse Files\\21-27 Sep\\";
	$listFile =scandir( $address, 1);
	foreach($listFile as $name)
	{
		echo "$address$name<br>";
	//	parsefile($address.$name);
	}


}
//echo "Hello";
execute();
?>
